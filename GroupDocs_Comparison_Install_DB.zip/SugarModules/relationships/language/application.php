<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$app_list_strings['parent_type_display']['gdocssig_GroupDocs_Signature'] = 'GroupDocs_Signature';
$app_list_strings['record_type_display']['gdocssig_GroupDocs_Signature'] = 'GroupDocs_Signature';
$app_list_strings['record_type_display_notes']['gdocssig_GroupDocs_Signature'] = 'GroupDocs_Signature';
