<?php
// created: 2012-08-21 21:28:17
$dictionary["gdocsc_GroupDocs_Comparison"]["fields"]["gdocsc_groupdocs_Comparison_project"] = array (
  'name' => 'gdocsc_groupdocs_Comparison_project',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_Comparison_project',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_PROJECT_FROM_PROJECT_TITLE',
);
