<?php
// created: 2012-08-21 21:28:16
$dictionary["gdocsc_GroupDocs_Comparison"]["fields"]["gdocsc_groupdocs_Comparison_activities_tasks"] = array (
  'name' => 'gdocsc_groupdocs_Comparison_activities_tasks',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_Comparison_activities_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_ACTIVITIES_TASKS_FROM_TASKS_TITLE',
);
