<?php
// created: 2012-08-21 21:28:16
$dictionary["Note"]["fields"]["gdocsc_groupdocs_comparison_activities_notes"] = array (
  'name' => 'gdocsc_groupdocs_comparison_activities_notes',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_comparison_activities_notes',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_ACTIVITIES_NOTES_FROM_GDOCSC_GROUPDOCS_COMPARISON_TITLE',
);
