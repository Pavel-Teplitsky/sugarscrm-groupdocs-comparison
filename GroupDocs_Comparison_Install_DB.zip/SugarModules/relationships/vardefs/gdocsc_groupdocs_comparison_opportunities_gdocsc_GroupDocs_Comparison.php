<?php
// created: 2012-08-21 21:28:16
$dictionary["gdocsc_GroupDocs_Comparison"]["fields"]["gdocsc_groupdocs_Comparison_opportunities"] = array (
  'name' => 'gdocsc_groupdocs_Comparison_opportunities',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_Comparison_opportunities',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_OPPORTUNITIES_FROM_OPPORTUNITIES_TITLE',
);
