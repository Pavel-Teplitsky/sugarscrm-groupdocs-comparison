<?php
// created: 2012-08-21 21:28:16
$dictionary["gdocsc_GroupDocs_Comparison"]["fields"]["gdocsc_groupdocs_comparison_contacts"] = array (
  'name' => 'gdocsc_groupdocs_comparison_contacts',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_comparison_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_CONTACTS_FROM_CONTACTS_TITLE',
);
