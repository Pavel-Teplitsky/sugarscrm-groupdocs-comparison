<?php
// created: 2012-08-21 21:28:16
$dictionary["Account"]["fields"]["gdocsc_groupdocs_comparison_accounts"] = array (
  'name' => 'gdocsc_groupdocs_comparison_accounts',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_comparison_accounts',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_ACCOUNTS_FROM_GDOCSC_GROUPDOCS_COMPARISON_TITLE',
);
