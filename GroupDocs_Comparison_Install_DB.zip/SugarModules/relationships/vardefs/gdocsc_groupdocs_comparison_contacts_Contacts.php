<?php
// created: 2012-08-21 21:28:16
$dictionary["Contact"]["fields"]["gdocsc_groupdocs_comparison_contacts"] = array (
  'name' => 'gdocsc_groupdocs_comparison_contacts',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_comparison_contacts',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_CONTACTS_FROM_GDOCSC_GROUPDOCS_COMPARISON_TITLE',
);
