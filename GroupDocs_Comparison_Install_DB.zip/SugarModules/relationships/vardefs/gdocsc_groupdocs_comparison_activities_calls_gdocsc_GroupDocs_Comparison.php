<?php
// created: 2012-08-21 21:28:16
$dictionary["gdocsc_GroupDocs_Comparison"]["fields"]["gdocsc_groupdocs_comparison_activities_calls"] = array (
  'name' => 'gdocsc_groupdocs_comparison_activities_calls',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_comparison_activities_calls',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
