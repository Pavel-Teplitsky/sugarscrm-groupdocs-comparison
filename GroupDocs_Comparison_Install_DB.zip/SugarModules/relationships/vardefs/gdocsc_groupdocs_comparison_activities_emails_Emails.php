<?php
// created: 2012-08-21 21:28:16
$dictionary["Email"]["fields"]["gdocsc_groupdocs_comparison_activities_emails"] = array (
  'name' => 'gdocsc_groupdocs_comparison_activities_emails',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_comparison_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_ACTIVITIES_EMAILS_FROM_GDOCSC_GROUPDOCS_COMPARISON_TITLE',
);
