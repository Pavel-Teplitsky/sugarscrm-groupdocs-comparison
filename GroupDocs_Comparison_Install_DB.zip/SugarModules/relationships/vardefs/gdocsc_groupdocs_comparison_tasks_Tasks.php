<?php
// created: 2012-08-21 21:28:17
$dictionary["Task"]["fields"]["gdocsc_groupdocs_Comparison_tasks"] = array (
  'name' => 'gdocsc_groupdocs_Comparison_tasks',
  'type' => 'link',
  'relationship' => 'gdocsc_groupdocs_Comparison_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_GDOCSC_GROUPDOCS_COMPARISON_TASKS_FROM_GDOCSC_GROUPDOCS_COMPARISON_TITLE',
);
