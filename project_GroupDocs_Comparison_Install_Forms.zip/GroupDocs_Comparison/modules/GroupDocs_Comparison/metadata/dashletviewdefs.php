<?php
$dashletData['gdocsc_GroupDocs_ComparisonDashlet']['searchFields'] = array (
  'date_entered' => 
  array (
    'default' => '',
  ),
  'date_modified' => 
  array (
    'default' => '',
  ),
  'assigned_user_id' => 
  array (
    'type' => 'assigned_user_name',
    'default' => 'GroupDocs Administrator',
  ),
);
$dashletData['gdocsc_GroupDocs_ComparisonDashlet']['columns'] = array (
  'iframe' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_IFRAME',
    'width' => '10%',
    'default' => true,
    'name' => 'iframe',
  ),
  'created_by' => 
  array (
    'width' => '8%',
    'label' => 'LBL_CREATED',
    'name' => 'created_by',
    'default' => false,
  ),
  'assigned_user_name' => 
  array (
    'width' => '8%',
    'label' => 'LBL_LIST_ASSIGNED_USER',
    'name' => 'assigned_user_name',
    'default' => false,
  ),
  'date_entered' => 
  array (
    'type' => 'datetime',
    'label' => 'LBL_DATE_ENTERED',
    'width' => '10%',
    'default' => false,
  ),
);
